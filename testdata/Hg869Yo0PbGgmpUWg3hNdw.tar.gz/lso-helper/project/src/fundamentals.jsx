// fundamentals.jsx — Full 5-pillar Fundamentals view

const { useState, useEffect, useCallback } = React;

const fmtB = v => v == null ? '—' : v >= 1e9 ? `$${(v/1e9).toFixed(1)}B` : v >= 1e6 ? `$${(v/1e6).toFixed(0)}M` : `$${v.toFixed(0)}`;
const fmtPct = v => v == null ? '—' : `${v >= 0 ? '' : ''}${v.toFixed(1)}%`;

// ── Inline sparkline (SVG) ─────────────────────────────────────────────────
function Spark({ series, color = 'var(--clr-accent)', width = 200, height = 52, fill = true, label }) {
  if (!series?.points?.length) return null;
  const pts = series.points;
  const vals = pts.map(p => p.value);
  const minV = Math.min(...vals), maxV = Math.max(...vals);
  const rng = maxV - minV || 1;
  const px = i => (i / (pts.length - 1)) * width;
  const py = v => height - 4 - ((v - minV) / rng) * (height - 10);
  const d = vals.map((v, i) => `${i === 0 ? 'M' : 'L'}${px(i).toFixed(1)},${py(v).toFixed(1)}`).join(' ');
  const fillPath = `${d} L${px(pts.length-1)},${height} L0,${height} Z`;
  const last = vals[vals.length - 1];
  const prev = vals[vals.length - 2];
  const trend = last > prev * 1.01 ? 'up' : last < prev * 0.99 ? 'down' : 'flat';
  const trendColor = trend === 'up' ? 'var(--clr-accent)' : trend === 'down' ? 'var(--clr-red)' : 'var(--clr-muted)';

  return (
    <div>
      {label && (
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 4 }}>
          <span style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600 }}>{label}</span>
          <span style={{ fontSize: 11, fontFamily: 'var(--font-mono)', color: trendColor }}>
            {trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'} {fmtB(last)}
          </span>
        </div>
      )}
      <svg width={width} height={height} style={{ display: 'block', overflow: 'visible' }}>
        {fill && <path d={fillPath} fill={color} fillOpacity={0.06} />}
        <path d={d} fill="none" stroke={color} strokeWidth="1.75" strokeLinejoin="round" strokeLinecap="round" />
        <circle cx={px(vals.length-1)} cy={py(last)} r="3" fill={color} />
      </svg>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 2 }}>
        <span style={{ fontSize: 9, color: 'var(--clr-muted)', fontFamily: 'var(--font-mono)' }}>{pts[0]?.date?.slice(0,7)}</span>
        <span style={{ fontSize: 9, color: 'var(--clr-muted)', fontFamily: 'var(--font-mono)' }}>{pts[pts.length-1]?.date?.slice(0,7)}</span>
      </div>
    </div>
  );
}

// ── Two-series line chart ──────────────────────────────────────────────────
function DualSpark({ s1, s2, color1 = 'var(--clr-accent)', color2 = 'var(--clr-gold)', width = 320, height = 64 }) {
  const render = (series, color) => {
    if (!series?.points?.length) return null;
    const allVals = [...(s1?.points||[]), ...(s2?.points||[])].map(p => p.value);
    const minV = Math.min(...allVals), maxV = Math.max(...allVals);
    const rng = maxV - minV || 1;
    const pts = series.points;
    const px = i => (i / (pts.length - 1)) * width;
    const py = v => height - 4 - ((v - minV) / rng) * (height - 10);
    const d = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${px(i).toFixed(1)},${py(p.value).toFixed(1)}`).join(' ');
    return <path key={color} d={d} fill="none" stroke={color} strokeWidth="1.75" strokeLinejoin="round" strokeLinecap="round" />;
  };
  return (
    <svg width={width} height={height} style={{ display: 'block', overflow: 'visible' }}>
      {render(s1, color1)}{render(s2, color2)}
    </svg>
  );
}

// ── Rating gauge ──────────────────────────────────────────────────────────
function RatingBar({ buy = 0, hold = 0, sell = 0 }) {
  const total = buy + hold + sell || 1;
  return (
    <div style={{ display: 'flex', gap: 2, height: 8, borderRadius: 4, overflow: 'hidden', width: '100%' }}>
      <div style={{ width: `${(buy/total)*100}%`, background: 'var(--clr-accent)' }} />
      <div style={{ width: `${(hold/total)*100}%`, background: 'var(--clr-gold)' }} />
      <div style={{ width: `${(sell/total)*100}%`, background: 'var(--clr-red)' }} />
    </div>
  );
}

// ── Band indicator ────────────────────────────────────────────────────────
function BandBadge({ band }) {
  if (!band) return null;
  const bg  = band.passing ? 'rgba(42,107,78,0.1)'  : 'rgba(184,60,60,0.08)';
  const fg  = band.passing ? 'var(--clr-accent)'    : 'var(--clr-red)';
  const bdr = band.passing ? 'rgba(42,107,78,0.2)'  : 'rgba(184,60,60,0.18)';
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 10px', borderRadius: 999, background: bg, color: fg, border: `1px solid ${bdr}`, fontSize: 12, fontWeight: 600 }}>
      {band.passing ? '✓' : '✗'} {band.formatted} <span style={{ opacity: 0.7, fontSize: 11 }}>{band.label}</span>
    </span>
  );
}

// ── Pillar section wrapper ────────────────────────────────────────────────
function PillarSection({ num, icon, title, subtitle, score, children }) {
  const scoreColor = score >= 70 ? 'var(--clr-accent)' : score >= 45 ? 'var(--clr-gold)' : 'var(--clr-red)';
  return (
    <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
      {/* Header */}
      <div style={{ padding: '18px 24px', borderBottom: '1px solid var(--clr-border)', display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ width: 40, height: 40, borderRadius: 10, background: 'rgba(42,107,78,0.1)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
          {icon}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
            <span style={{ fontSize: 10, color: 'var(--clr-muted)', fontFamily: 'var(--font-mono)', letterSpacing: '0.06em' }}>PILLAR {num}</span>
          </div>
          <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--clr-text)', lineHeight: 1.2 }}>{title}</div>
          <div style={{ fontSize: 12, color: 'var(--clr-muted)', marginTop: 1, fontStyle: 'italic' }}>{subtitle}</div>
        </div>
        <div style={{ textAlign: 'right', flexShrink: 0 }}>
          <div style={{ fontSize: 10, color: 'var(--clr-muted)', marginBottom: 3, textTransform: 'uppercase', letterSpacing: '0.06em' }}>Score</div>
          <div style={{ fontSize: 26, fontWeight: 700, fontFamily: 'var(--font-mono)', color: scoreColor, lineHeight: 1 }}>{score}</div>
          <div style={{ height: 4, width: 60, background: 'var(--clr-border)', borderRadius: 2, marginTop: 4 }}>
            <div style={{ height: '100%', width: `${score}%`, background: scoreColor, borderRadius: 2 }} />
          </div>
        </div>
      </div>
      {/* Body */}
      <div style={{ padding: '20px 24px' }}>{children}</div>
    </div>
  );
}

// ── Key metric box ─────────────────────────────────────────────────────────
function MetricBox({ label, value, sub, accent, band, flag }) {
  const color = accent || (band ? (band.passing ? 'var(--clr-accent)' : 'var(--clr-red)') : 'var(--clr-text)');
  return (
    <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 16px' }}>
      <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600, marginBottom: 4 }}>{label}</div>
      <div style={{ fontFamily: 'var(--font-mono)', fontSize: 20, fontWeight: 700, color, lineHeight: 1 }}>{value || '—'}</div>
      {band && <div style={{ marginTop: 6 }}><BandBadge band={band} /></div>}
      {sub && <div style={{ fontSize: 11, color: 'var(--clr-muted)', marginTop: 4 }}>{sub}</div>}
      {flag && <div style={{ fontSize: 11, color: 'var(--clr-red)', marginTop: 4 }}>⚠ {flag}</div>}
    </div>
  );
}

// ── Red flag row ──────────────────────────────────────────────────────────
function RedFlags({ flags }) {
  if (!flags?.length) return null;
  return (
    <div style={{ marginTop: 14, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      {flags.map((f, i) => (
        <span key={i} style={{ fontSize: 11, background: 'rgba(184,60,60,0.07)', color: 'var(--clr-red)', border: '1px solid rgba(184,60,60,0.15)', borderRadius: 5, padding: '3px 10px' }}>⚠ {f}</span>
      ))}
    </div>
  );
}

// ── Mock data generator for pillars 3-5 (not in API yet) ─────────────────
function mockForTicker(ticker) {
  const seed = ticker.symbol.charCodeAt(0) + (ticker.symbol.charCodeAt(1) || 0);
  const rng = (min, max) => min + ((seed * 1.618 * (min + max)) % (max - min));
  const fcfVals = Array.from({ length: 8 }, (_, i) => ({ date: `2023-0${(i%4)+1}-01`, value: rng(-2e8, 8e8) + i * 5e7 }));
  const buyCount  = Math.round(rng(3, 25));
  const holdCount = Math.round(rng(2, 12));
  const sellCount = Math.round(rng(0, 6));
  const priceTarget = +(ticker.price * rng(0.9, 1.4)).toFixed(2);
  const sectorAvgMargin = +(ticker.sectorScore * 0.22).toFixed(1);
  const sectorAvgRevGrowth = +(ticker.sectorScore * 0.15).toFixed(1);
  return {
    fcf: { value: rng(1e8, 6e8), series: { points: fcfVals } },
    fcfPositive: rng(0, 1) > 0.2,
    analyst: { buy: buyCount, hold: holdCount, sell: sellCount, target: priceTarget, analysts: buyCount + holdCount + sellCount },
    sector: { revenueGrowth: +(ticker.income * 0.18).toFixed(1), sectorAvgRevGrowth, profitMarginPct: +(ticker.income * 0.22).toFixed(1), sectorAvgMargin, marketShareIndicator: rng(5, 40).toFixed(1) },
  };
}

// ── Main Fundamentals View ────────────────────────────────────────────────
function FundamentalsView({ ticker, onBack, env }) {
  const [company, setCompany]   = useState(null);
  const [income, setIncome]     = useState(null);
  const [balance, setBalance]   = useState(null);
  const [cashflow, setCashflow] = useState(null);
  const [warnings, setWarnings] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [cik, setCik]           = useState(null);
  const isProd = env === 'production';

  // Only use mock data in development
  const mock = isProd ? null : mockForTicker(ticker);

  useEffect(() => {
    setLoading(true);
    setCompany(null); setIncome(null); setBalance(null); setCashflow(null); setCik(null);

    API.getCompany(ticker.symbol).then(d => {
      if (d?.company) {
        setCompany(d.company);
        const foundCik = d.company.cik;
        setCik(foundCik);
        Promise.all([
          API.getFundamentals(foundCik),
          API.getIncomeStatement(foundCik),
          API.getBalanceSheet(foundCik),
          API.getCashFlow(foundCik),
        ]).then(([fund, inc, bal, cf]) => {
          if (fund?.warnings) setWarnings(fund.warnings);
          if (inc) setIncome(inc);
          if (bal) setBalance(bal);
          if (cf)  setCashflow(cf);
          setLoading(false);
        });
      } else {
        setLoading(false);
      }
    });
  }, [ticker.symbol]);

  const ttm = income?.ttm;
  const profitMargin = income?.profit_margin;
  const leverage = balance?.leverage;
  const freeCashFlow = cashflow?.free_cash_flow;
  const fcfYield = cashflow?.fcf_yield;

  // Analyst mock only available in dev
  const analystConsensus = mock
    ? (mock.analyst.buy > mock.analyst.hold + mock.analyst.sell ? 'Buy'
      : mock.analyst.sell > mock.analyst.buy + mock.analyst.hold ? 'Sell' : 'Hold')
    : null;
  const consensusColor = analystConsensus === 'Buy' ? 'var(--clr-accent)'
    : analystConsensus === 'Sell' ? 'var(--clr-red)' : 'var(--clr-gold)';

  // Placeholder shown when in prod and data not yet available
  function Placeholder({ message }) {
    return (
      <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '16px 20px', color: 'var(--clr-muted)', fontSize: 12, fontStyle: 'italic' }}>
        {message}
      </div>
    );
  }

  return (
    <div style={{ padding: '28px 32px', maxWidth: 900, margin: '0 auto' }}>
      {/* Back + title banner */}
      <div style={{ marginBottom: 24 }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', cursor: 'pointer', fontSize: 12, color: 'var(--clr-muted)', fontFamily: 'var(--font-sans)', display: 'flex', alignItems: 'center', gap: 5, padding: 0, marginBottom: 14 }}>
          ← Back to Shortlist
        </button>
        <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 12, padding: '20px 28px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 12, marginBottom: 4 }}>
              <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: 28, fontWeight: 700, color: 'var(--clr-accent)', margin: 0 }}>{ticker.symbol}</h1>
              <span style={{ fontFamily: 'var(--font-serif)', fontSize: 18, color: 'var(--clr-text)', fontStyle: 'italic' }}>{company?.name || ticker.name}</span>
            </div>
            <div style={{ fontSize: 12, color: 'var(--clr-muted)', display: 'flex', gap: 12, flexWrap: 'wrap' }}>
              <span>{company?.sector || ticker.sector}</span>
              {company?.industry && <span>· {company.industry}</span>}
              {company?.full_time_employees && <span>· {company.full_time_employees.toLocaleString()} employees</span>}
              {company?.website && <a href={company.website} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--clr-accent)', textDecoration: 'none' }}>↗ {company.website.replace(/^https?:\/\//,'')}</a>}
            </div>
            {company?.summary && (
              <p style={{ fontSize: 12, color: 'var(--clr-muted)', marginTop: 8, lineHeight: 1.6, maxWidth: 560, fontStyle: 'italic' }}>
                {company.summary.length > 240 ? company.summary.slice(0, 240) + '…' : company.summary}
              </p>
            )}
          </div>
          <div style={{ display: 'flex', gap: 20, flexShrink: 0, marginLeft: 24 }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Price</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 700 }}>${ticker.price.toFixed(2)}</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Overall</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 700, color: ticker.overall >= 70 ? 'var(--clr-accent)' : ticker.overall >= 45 ? 'var(--clr-gold)' : 'var(--clr-red)' }}>{ticker.overall}</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>Mkt Cap</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 700 }}>${ticker.mcap}B</div>
            </div>
          </div>
        </div>
        {warnings.length > 0 && (
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginTop: 10 }}>
            {warnings.map((w, i) => <span key={i} style={{ fontSize: 11, background: 'rgba(184,60,60,0.07)', color: 'var(--clr-red)', border: '1px solid rgba(184,60,60,0.15)', borderRadius: 5, padding: '3px 10px' }}>⚠ {w}</span>)}
          </div>
        )}
        {loading && <p style={{ fontSize: 12, color: 'var(--clr-muted)', marginTop: 8 }}>Loading from API…</p>}
      </div>

      {/* ── Pillar 1: Income Statement ── */}
      <PillarSection num="1" icon="📈" title="Income Statement" subtitle="Is the company making money?" score={ticker.income}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 18 }}>
          <MetricBox label="Revenue (TTM)"    value={ttm ? fmtB(ttm.total_revenue)    : (isProd ? '—' : `$${(ticker.mcap * 0.18).toFixed(1)}B`)} />
          <MetricBox label="Operating Income" value={ttm ? fmtB(ttm.operating_income) : (isProd ? '—' : `$${(ticker.mcap * 0.06).toFixed(1)}B`)} />
          <MetricBox label="Profit Margin"    value={profitMargin?.formatted || (isProd ? '—' : fmtPct(ticker.income * 0.22))} band={profitMargin} />
          <MetricBox label="Net Income (est.)" value={ttm ? fmtB(ttm.total_revenue * (profitMargin?.value ?? 0.1)) : (isProd ? '—' : `$${(ticker.mcap * 0.04).toFixed(1)}B`)} />
        </div>
        {income?.series ? (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 14px' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8, display: 'flex', gap: 12 }}>
                <span style={{ color: 'var(--clr-accent)' }}>— Revenue</span>
                <span style={{ color: 'var(--clr-gold)' }}>— Gross Profit</span>
              </div>
              <DualSpark s1={income.series.revenue} s2={income.series.gross_profit} width={280} height={64} />
            </div>
            <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 14px' }}>
              <Spark series={income.series.profit_margin} color="var(--clr-gold)" width={280} height={64} label="Profit Margin %" fill={false} />
            </div>
          </div>
        ) : (
          <Placeholder message={isProd ? 'Chart data will appear once the backend returns income statement series.' : 'Chart data available when connected to backend.'} />
        )}
        <RedFlags flags={ticker.income < 45 ? ['Low profitability score','Verify revenue growth trend'] : ticker.income < 70 ? ['Profit margin in borderline range'] : []} />
      </PillarSection>

      {/* ── Pillar 2: Balance Sheet ── */}
      <PillarSection num="2" icon="⚖️" title="Balance Sheet" subtitle="Financial stability check" score={ticker.balance}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 18 }}>
          <MetricBox label="Leverage" value={leverage?.formatted || (isProd ? '—' : (1.5 + (100 - ticker.balance) * 0.04).toFixed(2))} band={leverage} sub="Debt-to-equity" />
          <MetricBox label="Current Ratio (est.)" value={isProd ? '—' : (1.2 + (ticker.balance - 45) * 0.02).toFixed(2)} accent={!isProd ? (ticker.balance >= 60 ? 'var(--clr-accent)' : 'var(--clr-red)') : 'var(--clr-muted)'} sub={isProd ? 'Connect backend' : (ticker.balance >= 60 ? 'Adequate liquidity' : 'Liquidity concern')} />
          <MetricBox label="Intangibles %" value={isProd ? '—' : `${(8 + (100 - ticker.balance) * 0.1).toFixed(1)}%`} accent={isProd ? 'var(--clr-muted)' : ((100 - ticker.balance) * 0.1 + 8 > 10 ? 'var(--clr-red)' : 'var(--clr-accent)')} flag={!isProd && (100 - ticker.balance) * 0.1 + 8 > 10 ? 'High intangibles (>10%)' : null} />
        </div>
        {balance?.series ? (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 14px' }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: 8, display: 'flex', gap: 12 }}>
                <span style={{ color: 'var(--clr-accent)' }}>— Current Assets</span>
                <span style={{ color: 'var(--clr-red)' }}>— Current Liabilities</span>
              </div>
              <DualSpark s1={balance.series.current_assets} s2={balance.series.current_liabilities} color1="var(--clr-accent)" color2="var(--clr-red)" width={280} height={64} />
            </div>
            <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 14px' }}>
              <Spark series={balance.series.leverage} color="var(--clr-gold)" width={280} height={64} label="Leverage Trend" fill={false} />
            </div>
          </div>
        ) : (
          <Placeholder message={isProd ? 'Chart data will appear once the backend returns balance sheet series.' : 'Chart data available when connected to backend.'} />
        )}
        <RedFlags flags={[
          ticker.balance < 50 ? 'Low balance sheet score — verify debt levels' : null,
          !isProd && (100 - ticker.balance) * 0.1 + 8 > 10 ? 'High intangible assets ratio' : null,
        ].filter(Boolean)} />
      </PillarSection>

      {/* ── Pillar 3: Cash Flow ── */}
      <PillarSection num="3" icon="💰" title="Cash Flow Statement" subtitle="Following the money" score={ticker.cashflow}>
        {cashflow ? (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 18 }}>
              <MetricBox label="Free Cash Flow" value={freeCashFlow?.formatted || '—'} band={freeCashFlow} sub={freeCashFlow?.passing ? 'Positive — healthy' : freeCashFlow ? 'Negative — watch closely' : null} />
              <MetricBox label="FCF Yield" value={fcfYield?.formatted || '—'} band={fcfYield} />
              <MetricBox label="Cash Flow Trend" value={ticker.cashflow >= 70 ? 'Positive' : ticker.cashflow >= 45 ? 'Mixed' : 'Declining'} accent={ticker.cashflow >= 70 ? 'var(--clr-accent)' : ticker.cashflow >= 45 ? 'var(--clr-gold)' : 'var(--clr-red)'} />
            </div>
            {cashflow.series?.free_cash_flow && (
              <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 16px' }}>
                <Spark series={cashflow.series.free_cash_flow} color="var(--clr-accent)" width={480} height={64} label="Free Cash Flow" />
              </div>
            )}
          </>
        ) : mock ? (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12, marginBottom: 18 }}>
              <MetricBox label="Free Cash Flow (est.)" value={fmtB(mock.fcf.value)} accent={mock.fcfPositive ? 'var(--clr-accent)' : 'var(--clr-red)'} sub={mock.fcfPositive ? 'Positive — healthy' : 'Negative — watch closely'} />
              <MetricBox label="Cash Flow Trend" value={ticker.cashflow >= 70 ? 'Positive' : ticker.cashflow >= 45 ? 'Mixed' : 'Declining'} accent={ticker.cashflow >= 70 ? 'var(--clr-accent)' : ticker.cashflow >= 45 ? 'var(--clr-gold)' : 'var(--clr-red)'} />
              <MetricBox label="FCF Yield (est.)" value={`${(mock.fcf.value / (ticker.mcap * 1e9) * 100).toFixed(1)}%`} />
            </div>
            <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 16px' }}>
              <Spark series={mock.fcf.series} color="var(--clr-accent)" width={480} height={64} label="Free Cash Flow trend (estimated)" />
            </div>
            <RedFlags flags={[!mock.fcfPositive ? 'Negative FCF — potential cash burn risk' : null, ticker.cashflow < 50 ? 'Low cash flow score — verify operating cash generation' : null].filter(Boolean)} />
          </>
        ) : (
          <Placeholder message="Cash flow data will appear once the backend returns /cash-flow series." />
        )}
      </PillarSection>

      {/* ── Pillar 4: Sector & Competitive Analysis ── */}
      <PillarSection num="4" icon="🔭" title="Sector & Competitive Analysis" subtitle="Context matters" score={ticker.sectorScore}>
        {mock ? (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            <div>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
                <MetricBox label="Revenue Growth (est.)" value={`${mock.sector.revenueGrowth}%`} accent={mock.sector.revenueGrowth > mock.sector.sectorAvgRevGrowth ? 'var(--clr-accent)' : 'var(--clr-red)'} sub={`Sector avg: ${mock.sector.sectorAvgRevGrowth}%`} />
                <MetricBox label="Profit Margin" value={`${mock.sector.profitMarginPct}%`} accent={mock.sector.profitMarginPct > mock.sector.sectorAvgMargin ? 'var(--clr-accent)' : 'var(--clr-red)'} sub={`Sector avg: ${mock.sector.sectorAvgMargin}%`} />
              </div>
              <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 16px' }}>
                <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600, marginBottom: 10 }}>vs. Sector Average</div>
                {[
                  { label: 'Rev. Growth', company: mock.sector.revenueGrowth, sector: mock.sector.sectorAvgRevGrowth },
                  { label: 'Profit Margin', company: mock.sector.profitMarginPct, sector: mock.sector.sectorAvgMargin },
                ].map(row => {
                  const maxVal = Math.max(row.company, row.sector, 1);
                  return (
                    <div key={row.label} style={{ marginBottom: 10 }}>
                      <div style={{ fontSize: 11, color: 'var(--clr-muted)', marginBottom: 3 }}>{row.label}</div>
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 2 }}>
                        <div style={{ fontSize: 10, color: 'var(--clr-text)', width: 80, fontFamily: 'var(--font-mono)' }}>{ticker.symbol}</div>
                        <div style={{ flex: 1, height: 8, background: 'var(--clr-border)', borderRadius: 2 }}>
                          <div style={{ width: `${(row.company/maxVal)*100}%`, height: '100%', background: 'var(--clr-accent)', borderRadius: 2 }} />
                        </div>
                        <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', width: 40, textAlign: 'right', color: 'var(--clr-accent)' }}>{row.company}%</span>
                      </div>
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <div style={{ fontSize: 10, color: 'var(--clr-muted)', width: 80, fontFamily: 'var(--font-mono)' }}>Sector</div>
                        <div style={{ flex: 1, height: 8, background: 'var(--clr-border)', borderRadius: 2 }}>
                          <div style={{ width: `${(row.sector/maxVal)*100}%`, height: '100%', background: 'rgba(154,122,58,0.5)', borderRadius: 2 }} />
                        </div>
                        <span style={{ fontSize: 10, fontFamily: 'var(--font-mono)', width: 40, textAlign: 'right', color: 'var(--clr-gold)' }}>{row.sector}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
            <div>
              <MetricBox label="Market Position" value={`${mock.sector.marketShareIndicator}%`} sub="Estimated market share in segment" />
              <div style={{ marginTop: 12, background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 16px' }}>
                <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600, marginBottom: 6 }}>Sector</div>
                <div style={{ fontSize: 14, fontWeight: 600 }}>{company?.sector || ticker.sector}</div>
                {company?.industry && <div style={{ fontSize: 12, color: 'var(--clr-muted)', marginTop: 2 }}>{company.industry}</div>}
              </div>
            </div>
          </div>
        ) : (
          <Placeholder message="Sector comparison data is not yet available from the backend." />
        )}
      </PillarSection>

      {/* ── Pillar 5: Analyst Assessments ── */}
      <PillarSection num="5" icon="🔬" title="Analyst Assessments" subtitle="Using expert opinions wisely" score={ticker.analyst}>
        {mock ? (
          <>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 12, marginBottom: 18 }}>
              <MetricBox label="Consensus" value={analystConsensus} accent={consensusColor} />
              <MetricBox label="Avg Price Target" value={`$${mock.analyst.target}`} accent={mock.analyst.target > ticker.price ? 'var(--clr-accent)' : 'var(--clr-red)'} sub={mock.analyst.target > ticker.price ? `↑ ${((mock.analyst.target/ticker.price-1)*100).toFixed(0)}% upside` : `↓ ${((1-mock.analyst.target/ticker.price)*100).toFixed(0)}% downside`} />
              <MetricBox label="# Analysts" value={mock.analyst.analysts} />
              <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 16px' }}>
                <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600, marginBottom: 8 }}>Breakdown</div>
                <RatingBar buy={mock.analyst.buy} hold={mock.analyst.hold} sell={mock.analyst.sell} />
                <div style={{ display: 'flex', gap: 10, marginTop: 6 }}>
                  <span style={{ fontSize: 10, color: 'var(--clr-accent)' }}>Buy {mock.analyst.buy}</span>
                  <span style={{ fontSize: 10, color: 'var(--clr-gold)' }}>Hold {mock.analyst.hold}</span>
                  <span style={{ fontSize: 10, color: 'var(--clr-red)' }}>Sell {mock.analyst.sell}</span>
                </div>
              </div>
            </div>
            <div style={{ background: 'var(--clr-bg)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '14px 18px' }}>
              <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600, marginBottom: 10 }}>Price vs. Target Range</div>
              <div style={{ position: 'relative', height: 12, background: 'var(--clr-border)', borderRadius: 6 }}>
                {(() => {
                  const lo = mock.analyst.target * 0.85, hi = mock.analyst.target * 1.15;
                  const domain = hi - lo * 0.85;
                  const rangePct = ((hi - lo) / domain) * 100;
                  const rangeStart = ((lo - lo * 0.85) / domain) * 100;
                  const currentPct = Math.min(100, Math.max(0, ((ticker.price - lo * 0.85) / domain) * 100));
                  const targetPct  = Math.min(100, Math.max(0, ((mock.analyst.target - lo * 0.85) / domain) * 100));
                  return (
                    <>
                      <div style={{ position: 'absolute', left: `${rangeStart}%`, width: `${rangePct}%`, height: '100%', background: 'rgba(42,107,78,0.2)', borderRadius: 4 }} />
                      <div style={{ position: 'absolute', left: `${targetPct}%`, top: -2, width: 2, height: 16, background: 'var(--clr-accent)', borderRadius: 1 }} title={`Target: $${mock.analyst.target}`} />
                      <div style={{ position: 'absolute', left: `${currentPct}%`, top: -3, width: 4, height: 18, background: 'var(--clr-text)', borderRadius: 2 }} title={`Current: $${ticker.price}`} />
                    </>
                  );
                })()}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 5 }}>
                <span style={{ fontSize: 10, color: 'var(--clr-muted)', fontFamily: 'var(--font-mono)' }}>Low target: ${(mock.analyst.target*0.85).toFixed(2)}</span>
                <span style={{ fontSize: 10, color: 'var(--clr-accent)', fontFamily: 'var(--font-mono)' }}>Avg: ${mock.analyst.target} ↑</span>
                <span style={{ fontSize: 10, color: 'var(--clr-muted)', fontFamily: 'var(--font-mono)' }}>High: ${(mock.analyst.target*1.15).toFixed(2)}</span>
              </div>
            </div>
          </>
        ) : (
          <Placeholder message="Analyst consensus data is not yet available from the backend." />
        )}
      </PillarSection>
    </div>
  );
}

Object.assign(window, { FundamentalsView });
