// Low Stress Options — SEED DATA (UI bootstrap)
//
// Hydrates window.TICKERS / window.POSITIONS / window.LSO_LISTS — the lookup
// tables components read directly (filters, layout, list memberships). This
// is bootstrap data only, not API response data; live API calls go through
// window.API and are routed by src/api.js (mocked in dev via /mocks.json).

const LSO_TICKERS = [
  // [symbol, name, sector, price, mcapB, income, balance, cashflow, sectorScore, analyst, rsi, bbPct, premiumPct, daysToEarnings, inShortlist]
  ['AAPL', 'Apple Inc.',             'Technology',  185.5, 2800, 88, 82, 90, 85, 80, 62, 74, 0.45, 38, true ],
  ['MSFT', 'Microsoft Corp.',        'Technology',  379.8, 2810, 92, 88, 94, 90, 87, 68, 81, 0.32, 22, true ],
  ['INTC', 'Intel Corp.',            'Technology',   22.4,   96, 48, 55, 42, 52, 44, 32, 22, 1.68, 15, true ],
  ['CSCO', 'Cisco Systems',          'Technology',   47.8,  198, 74, 78, 72, 68, 70, 35,  8, 1.45,  6, true ],
  ['IBM',  'IBM Corp.',              'Technology',   38.2,  154, 62, 59, 58, 55, 65, 48, 44, 0.68, 51, true ],
  ['TXN',  'Texas Instruments',      'Technology',   42.9,  154, 76, 80, 78, 70, 74, 50, 55, 0.55, 37, true ],
  ['AMAT', 'Applied Materials',      'Technology',   28.5,  168, 80, 74, 82, 78, 78, 60, 70, 0.41, 28, false],
  ['AMD',  'Adv. Micro Devices',     'Technology',   27.3,  282, 72, 65, 74, 80, 74, 58, 67, 0.52, 29, false],
  ['NVDA', 'NVIDIA Corp.',           'Technology',   45.0, 2030, 90, 78, 88, 92, 85, 71, 88, 0.28, 16, false],
  ['CRM',  'Salesforce Inc.',        'Technology',   38.4,  269, 68, 62, 65, 74, 72, 52, 62, 0.38, 44, false],
  ['PYPL', 'PayPal Holdings',        'Technology',   21.2,   65, 55, 58, 60, 58, 52, 46, 51, 0.72, 19, false],

  ['JPM',  'JPMorgan Chase',         'Finance',      39.8,  565, 84, 86, 82, 88, 82, 58, 68, 0.42, 25, true ],
  ['BAC',  'Bank of America',        'Finance',      19.2,  270, 72, 74, 68, 78, 70, 38, 18, 1.45, 22, true ],
  ['WFC',  'Wells Fargo',            'Finance',      28.4,  201, 68, 70, 65, 72, 65, 44, 38, 0.88, 31, true ],
  ['USB',  'US Bancorp',             'Finance',      19.5,   65, 65, 68, 62, 64, 62, 38, 26, 0.78, 33, true ],
  ['RF',   'Regions Financial',      'Finance',      19.8,   21, 60, 62, 58, 60, 58, 42, 19, 1.55, 24, true ],
  ['C',    'Citigroup Inc.',         'Finance',      49.7,  117, 62, 65, 60, 68, 60, 46, 46, 0.78, 42, false],
  ['MS',   'Morgan Stanley',         'Finance',      38.3,  152, 76, 78, 74, 80, 76, 54, 60, 0.52, 14, false],

  ['JNJ',  'Johnson & Johnson',      'Healthcare',   38.6,  372, 82, 85, 80, 78, 82, 48, 52, 0.58, 45, true ],
  ['PFE',  'Pfizer Inc.',            'Healthcare',   24.3,  154, 58, 62, 55, 52, 60, 34,  8, 1.82, 42, true ],
  ['MRK',  'Merck & Co.',            'Healthcare',   38.8,  317, 78, 80, 76, 75, 80, 52, 55, 0.55, 32, true ],
  ['BMY',  'Bristol-Myers Squibb',   'Healthcare',   22.5,   98, 65, 68, 62, 60, 62, 41, 31, 1.45, 15, true ],
  ['ABBV', 'AbbVie Inc.',            'Healthcare',   43.7,  289, 80, 76, 78, 72, 80, 54, 58, 0.52, 38, true ],
  ['WBA',  'Walgreens Boots',        'Healthcare',   14.3,   14, 38, 42, 35, 32, 30, 26, 15, 3.40, 28, true ],
  ['ABT',  'Abbott Laboratories',    'Healthcare',   32.9,  190, 76, 78, 74, 72, 76, 50, 50, 0.60, 27, false],
  ['CVS',  'CVS Health Corp.',       'Healthcare',   26.4,   79, 62, 60, 58, 55, 58, 48, 46, 0.75, 21, false],

  ['XOM',  'ExxonMobil Corp.',       'Energy',       44.4,  440, 78, 82, 80, 72, 76, 55, 60, 0.58, 34, true ],
  ['OXY',  'Occidental Petroleum',   'Energy',       37.8,   53, 65, 68, 62, 58, 60, 44, 42, 0.82, 15, true ],
  ['DVN',  'Devon Energy Corp.',     'Energy',       28.6,   26, 68, 65, 66, 60, 62, 35, 35, 1.18, 11, true ],
  ['HAL',  'Halliburton Co.',        'Energy',       22.2,   30, 65, 62, 60, 58, 62, 39, 28, 1.22, 11, true ],
  ['COP',  'ConocoPhillips',         'Energy',       48.6,  152, 80, 82, 78, 75, 78, 56, 62, 0.48, 28, true ],
  ['CVX',  'Chevron Corp.',          'Energy',       33.7,  295, 76, 80, 78, 70, 74, 52, 56, 0.52, 22, false],

  ['TGT',  'Target Corp.',           'Consumer',     42.8,   67, 70, 68, 72, 74, 70, 50, 50, 0.62, 35, true ],
  ['KO',   'Coca-Cola Co.',          'Consumer',     34.8,  267, 75, 72, 74, 78, 78, 50, 52, 0.65, 48, true ],
  ['SBUX', 'Starbucks Corp.',        'Consumer',     36.4,   88, 65, 58, 62, 68, 64, 46, 44, 0.80, 22, true ],
  ['WMT',  'Walmart Inc.',           'Consumer',     38.4,  453, 78, 75, 76, 82, 80, 58, 66, 0.40, 41, false],
  ['HD',   'Home Depot Inc.',        'Consumer',     44.5,  362, 82, 78, 84, 80, 82, 60, 68, 0.38, 26, false],
  ['PEP',  'PepsiCo Inc.',           'Consumer',     34.9,  227, 76, 74, 75, 76, 78, 52, 56, 0.52, 33, false],

  ['F',    'Ford Motor Co.',         'Industrial',   11.8,   47, 48, 45, 42, 50, 46, 28, 12, 2.15, 35, true ],
  ['GM',   'General Motors Co.',     'Industrial',   44.9,   50, 58, 55, 55, 58, 56, 37, 21, 1.30, 19, true ],
  ['CAT',  'Caterpillar Inc.',       'Industrial',   42.6,  162, 80, 78, 82, 80, 80, 58, 65, 0.42, 44, false],
  ['BA',   'Boeing Co.',             'Industrial',   38.2,  110, 35, 28, 22, 45, 38, 45, 42, 0.92, 31, true ],

  ['T',    'AT&T Inc.',              'Telecom',      19.4,  140, 52, 48, 50, 55, 50, 36, 24, 1.35, 18, true ],
  ['VZ',   'Verizon Communications', 'Telecom',      41.8,  176, 55, 52, 54, 58, 54, 38, 29, 0.85, 22, true ],
  ['DIS',  'Walt Disney Co.',        'Media',        28.6,  164, 58, 55, 52, 65, 62, 46, 48, 0.72, 27, true ],
  ['NFLX', 'Netflix Inc.',           'Media',        48.3,  194, 72, 65, 68, 70, 74, 55, 62, 0.45, 32, false],
  ['AMZN', 'Amazon.com Inc.',        'Technology',   49.5,  185, 80, 75, 82, 85, 82, 60, 70, 0.38, 28, false],
  ['GOOGL','Alphabet Inc.',          'Technology',   47.8, 2000, 85, 80, 88, 88, 84, 62, 72, 0.35, 35, false],
  ['META', 'Meta Platforms Inc.',    'Technology',   43.2,  110, 82, 76, 84, 82, 80, 60, 68, 0.40, 40, false],
];

const LIST_MEMBERSHIPS = {
  'Troy19':                  ['AAPL','MSFT','NVDA','GOOGL','META','AMD','CRM','JPM','MS','HD','WMT','XOM','COP','JNJ','ABBV','PEP','CAT','NFLX','VZ'],
  'Troy41':                  ['AAPL','MSFT','NVDA','GOOGL','META','AMD','CRM','PYPL','JPM','MS','BAC','C','WFC','USB','HD','WMT','PEP','KO','CAT','BA','XOM','COP','CVX','OXY','JNJ','ABT','MRK','ABBV','BMY','PFE','NFLX','DIS','AMZN','TGT','SBUX','VZ','T','IBM','TXN','AMAT','CSCO'],
  'John20':                  ['INTC','PFE','BAC','WBA','HAL','F','GM','T','BMY','RF','OXY','DVN','CVS','TGT','SBUX','BA','DIS','VZ','IBM','USB'],
  'Asymmetric Affordable AI':['AMD','INTC','CSCO','IBM','AMAT','PYPL','CRM','TXN'],
};

window.LSO_LISTS = [
  { id: 'My Shortlist',              label: 'My Shortlist',              short: '★',  color: 'oklch(50% 0.08 155)', editable: true  },
  { id: 'Troy19',                    label: 'Troy19',                    short: 'T19',color: 'oklch(55% 0.12 240)', editable: false },
  { id: 'Troy41',                    label: 'Troy41',                    short: 'T41',color: 'oklch(50% 0.13 285)', editable: false },
  { id: 'John20',                    label: 'John20',                    short: 'J20',color: 'oklch(60% 0.13 45)',  editable: false },
  { id: 'Asymmetric Affordable AI',  label: 'Asymmetric Affordable AI',  short: 'AAI',color: 'oklch(55% 0.10 195)', editable: false },
];

window.TICKERS = LSO_TICKERS.map(([symbol, name, sector, price, mcap, income, balance, cashflow, sectorScore, analyst, rsi, bbPct, premiumPct, daysToEarnings, inShortlist]) => {
  const overall = Math.round((income + balance + cashflow + sectorScore + analyst) / 5);
  const externalLists = Object.entries(LIST_MEMBERSHIPS)
    .filter(([_, syms]) => syms.includes(symbol))
    .map(([id]) => id);
  return { symbol, name, sector, price, mcap, income, balance, cashflow, sectorScore, analyst, overall, rsi, bbPct, premiumPct, daysToEarnings, inShortlist, externalLists };
});

window.POSITIONS = [
  { symbol:'INTC', expiry:'2025-03-21', strike:19,  type:'PUT', contracts:5,  openPremium:0.45, currentPremium:0.18, delta:-0.18, dte:28, status:'open' },
  { symbol:'BAC',  expiry:'2025-03-21', strike:16,  type:'PUT', contracts:8,  openPremium:0.52, currentPremium:0.22, delta:-0.22, dte:28, status:'open' },
  { symbol:'PFE',  expiry:'2025-03-21', strike:21,  type:'PUT', contracts:6,  openPremium:0.38, currentPremium:0.12, delta:-0.14, dte:28, status:'open' },
  { symbol:'WBA',  expiry:'2025-03-21', strike:12,  type:'PUT', contracts:10, openPremium:0.75, currentPremium:0.30, delta:-0.24, dte:28, status:'open' },
  { symbol:'HAL',  expiry:'2025-03-21', strike:19,  type:'PUT', contracts:4,  openPremium:0.42, currentPremium:0.16, delta:-0.19, dte:28, status:'open' },
  { symbol:'F',    expiry:'2025-03-21', strike:10,  type:'PUT', contracts:12, openPremium:0.28, currentPremium:0.10, delta:-0.20, dte:28, status:'open' },
  { symbol:'GM',   expiry:'2025-03-21', strike:38,  type:'PUT', contracts:3,  openPremium:0.68, currentPremium:0.25, delta:-0.20, dte:28, status:'open' },
  { symbol:'T',    expiry:'2025-03-21', strike:17,  type:'PUT', contracts:9,  openPremium:0.32, currentPremium:0.12, delta:-0.17, dte:28, status:'open' },
  { symbol:'KO',   expiry:'2025-02-21', strike:31,  type:'PUT', contracts:5,  openPremium:0.44, currentPremium:0.08, delta:-0.12, dte:7,  status:'open' },
  { symbol:'TGT',  expiry:'2025-02-21', strike:38,  type:'PUT', contracts:4,  openPremium:0.58, currentPremium:0.10, delta:-0.14, dte:7,  status:'open' },
  { symbol:'XOM',  expiry:'2025-02-21', strike:39,  type:'PUT', contracts:6,  openPremium:0.50, currentPremium:0.20, delta:-0.18, dte:7,  status:'open' },
  { symbol:'JNJ',  expiry:'2025-02-21', strike:34,  type:'PUT', contracts:5,  openPremium:0.40, currentPremium:0.32, delta:-0.28, dte:7,  status:'open' },
  { symbol:'INTC', expiry:'2025-01-17', strike:18,  type:'PUT', contracts:5,  openPremium:0.40, currentPremium:0.00, delta:0,     dte:0,  status:'closed', pnl: 200 },
  { symbol:'F',    expiry:'2025-01-17', strike:9,   type:'PUT', contracts:10, openPremium:0.24, currentPremium:0.00, delta:0,     dte:0,  status:'closed', pnl: 240 },
  { symbol:'T',    expiry:'2025-01-17', strike:16,  type:'PUT', contracts:8,  openPremium:0.30, currentPremium:0.00, delta:0,     dte:0,  status:'closed', pnl: 240 },
];

window.POSITIONS = window.POSITIONS.map(p => {
  if (p.status === 'closed') return p;
  const pnl = (p.openPremium - p.currentPremium) * 100 * p.contracts;
  const pnlPct = ((p.openPremium - p.currentPremium) / p.openPremium) * 100;
  const maxProfit = p.openPremium * 100 * p.contracts;
  const profitCapture = (pnl / maxProfit) * 100;
  return { ...p, pnl, pnlPct, maxProfit, profitCapture };
});
