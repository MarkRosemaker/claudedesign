// views.jsx — Shortlist table + Daily Scan

const { useState, useEffect, useMemo } = React;

const PILLARS = [
  { key: 'income',      label: 'Income',   icon: '📈' },
  { key: 'balance',     label: 'Balance',  icon: '⚖️' },
  { key: 'cashflow',    label: 'Cash',     icon: '💰' },
  { key: 'sectorScore', label: 'Sector',   icon: '🔭' },
  { key: 'analyst',     label: 'Analyst',  icon: '🔬' },
];

const SECTORS = ['All','Technology','Finance','Healthcare','Energy','Consumer','Industrial','Telecom','Media'];

function pillarColor(v) {
  return v >= 70 ? 'var(--clr-accent)' : v >= 45 ? 'var(--clr-gold)' : 'var(--clr-red)';
}

function trend(v) {
  return v >= 68 ? 'up' : v <= 45 ? 'down' : 'flat';
}

// Small inline indicator showing every list a ticker belongs to.
// One colored dot per list, with hover-tooltip via title.
function ListDots({ lists, size = 8 }) {
  if (!lists || lists.length === 0) return null;
  return (
    <span
      title={lists.map(l => l.label).join(', ')}
      style={{ display: 'inline-flex', alignItems: 'center', gap: 3, marginLeft: 2 }}
    >
      {lists.map(l => (
        <span key={l.id} style={{
          display: 'inline-block', width: size, height: size, borderRadius: '50%',
          background: l.color,
          boxShadow: '0 0 0 1px rgba(255,255,255,0.6)',
        }} />
      ))}
    </span>
  );
}

// Small inline number editor used in the Active Thresholds card.
// Renders a tight monospace input with optional prefix (e.g. "$") or suffix
// (e.g. "%", "d"). Click-to-edit; Enter / blur commits, Esc cancels, ↑/↓
// nudges by `step`. Empty input is ignored on commit.
function ThresholdNumInput({ value, onChange, min, max, step = 1, prefix, suffix, width = 48, decimals = 0 }) {
  const [draft, setDraft]   = useState(String(value));
  const [editing, setEditing] = useState(false);

  // Keep draft in sync with prop when not editing.
  useEffect(() => {
    if (!editing) setDraft(decimals > 0 ? Number(value).toFixed(decimals) : String(value));
  }, [value, editing, decimals]);

  function commit() {
    const n = parseFloat(draft);
    if (!isNaN(n)) {
      const clamped = Math.min(max, Math.max(min, n));
      const rounded = decimals > 0 ? Math.round(clamped * 10 ** decimals) / 10 ** decimals : Math.round(clamped);
      if (rounded !== value) onChange(rounded);
      setDraft(decimals > 0 ? rounded.toFixed(decimals) : String(rounded));
    } else {
      setDraft(decimals > 0 ? Number(value).toFixed(decimals) : String(value));
    }
    setEditing(false);
  }

  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center',
      background: editing ? 'var(--clr-bg)' : 'transparent',
      border: `1px solid ${editing ? 'var(--clr-accent)' : 'transparent'}`,
      borderRadius: 4,
      padding: '1px 4px',
      transition: 'border-color 0.1s, background 0.1s',
    }}
    onMouseEnter={e => { if (!editing) e.currentTarget.style.borderColor = 'var(--clr-border)'; }}
    onMouseLeave={e => { if (!editing) e.currentTarget.style.borderColor = 'transparent'; }}
    >
      {prefix && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--clr-muted)' }}>{prefix}</span>}
      <input
        type="number"
        value={draft}
        min={min} max={max} step={step}
        onChange={e => setDraft(e.target.value)}
        onFocus={() => setEditing(true)}
        onBlur={commit}
        onKeyDown={e => {
          if (e.key === 'Enter') { e.currentTarget.blur(); }
          else if (e.key === 'Escape') {
            setDraft(decimals > 0 ? Number(value).toFixed(decimals) : String(value));
            e.currentTarget.blur();
          }
        }}
        style={{
          width, background: 'transparent', border: 'none', outline: 'none',
          fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700,
          color: 'var(--clr-text)', textAlign: 'right', padding: 0,
          MozAppearance: 'textfield',
        }}
      />
      {suffix && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--clr-muted)' }}>{suffix}</span>}
    </span>
  );
}

// ── Shortlist ──────────────────────────────────────────────────────────────
// Helper: full list of lists a ticker belongs to, ordered to match LSO_LISTS.
function tickerLists(t) {
  const out = [];
  for (const def of (window.LSO_LISTS || [])) {
    if (def.id === 'My Shortlist') {
      if (t.inShortlist) out.push(def);
    } else if ((t.externalLists || []).includes(def.id)) {
      out.push(def);
    }
  }
  return out;
}

function Shortlist({ tickers, setTickers, onViewFundamentals, apiLive, env }) {
  const LISTS = window.LSO_LISTS || [];
  const [sector, setSector]         = useState('All');
  const [search, setSearch]         = useState('');
  // Multi-select list filter. Default: just My Shortlist (preserves prior view).
  // Empty set = full universe (no list filter).
  const [selectedLists, setSelectedLists] = useState(() => new Set(['My Shortlist']));
  const [sortKey, setSortKey]       = useState('overall');
  const [sortDir, setSortDir]       = useState('desc');
  const isProd = env === 'production';

  function toggleList(id) {
    setSelectedLists(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
  function clearLists() { setSelectedLists(new Set()); }

  // Membership check: is ticker `t` in list `id`?
  function inList(t, id) {
    if (id === 'My Shortlist') return !!t.inShortlist;
    return (t.externalLists || []).includes(id);
  }

  const filtered = useMemo(() => {
    let list = tickers;
    if (selectedLists.size > 0) {
      list = list.filter(t => [...selectedLists].some(id => inList(t, id)));
    }
    if (sector !== 'All') list = list.filter(t => t.sector === sector);
    if (search) list = list.filter(t =>
      t.symbol.includes(search.toUpperCase()) ||
      t.name.toLowerCase().includes(search.toLowerCase())
    );
    return [...list].sort((a, b) => (a[sortKey] - b[sortKey]) * (sortDir === 'desc' ? -1 : 1));
  }, [tickers, sector, search, selectedLists, sortKey, sortDir]);

  function toggleShortlist(symbol) {
    const ticker = tickers.find(t => t.symbol === symbol);
    if (!ticker) return;

    // Optimistically update local state
    setTickers(prev => prev.map(t =>
      t.symbol === symbol ? { ...t, inShortlist: !t.inShortlist } : t
    ));

    // In production, persist to backend
    if (isProd) {
      if (ticker.inShortlist) {
        API.removeFromWatchlist(symbol).then(r => {
          if (!r) {
            // Revert on failure
            setTickers(prev => prev.map(t =>
              t.symbol === symbol ? { ...t, inShortlist: true } : t
            ));
          }
        });
      } else {
        API.addToWatchlist(symbol).then(r => {
          if (!r) {
            setTickers(prev => prev.map(t =>
              t.symbol === symbol ? { ...t, inShortlist: false } : t
            ));
          }
        });
      }
    }
  }

  function handleSort(key) {
    if (sortKey === key) setSortDir(d => d === 'desc' ? 'asc' : 'desc');
    else { setSortKey(key); setSortDir('desc'); }
  }

  const shortlistCount = tickers.filter(t => t.inShortlist).length;
  const listCounts = useMemo(() => {
    const m = {};
    for (const def of LISTS) m[def.id] = tickers.filter(t => inList(t, def.id)).length;
    return m;
  }, [tickers]);

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 18, gap: 16 }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 700, margin: 0, fontStyle: 'italic' }}>Shortlist &amp; Fundamentals</h2>
          <p style={{ margin: '4px 0 0', color: 'var(--clr-muted)', fontSize: 13 }}>
            {shortlistCount} tickers in My Shortlist · click a row to open detailed fundamentals
            {isProd && apiLive && <span style={{ marginLeft: 8, color: 'var(--clr-accent)' }}>· watchlist synced with backend</span>}
            {isProd && !apiLive && <span style={{ marginLeft: 8, color: 'var(--clr-gold)' }}>· watchlist changes will not persist (IBKR offline)</span>}
          </p>
        </div>
      </div>

      {/* List filter — multi-select. Empty = full universe. */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 10, flexWrap: 'wrap', alignItems: 'center' }}>
        <span style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--clr-muted)', marginRight: 4 }}>Lists</span>
        <button onClick={clearLists} style={{
          padding: '5px 10px', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-sans)',
          background: selectedLists.size === 0 ? 'var(--clr-text)' : 'var(--clr-surface)',
          color:      selectedLists.size === 0 ? '#f0e8d8'        : 'var(--clr-muted)',
          border: selectedLists.size === 0 ? 'none' : '1px solid var(--clr-border)',
        }}>Full universe</button>
        {LISTS.map(def => {
          const active = selectedLists.has(def.id);
          return (
            <button key={def.id} onClick={() => toggleList(def.id)} title={def.label} style={{
              display: 'inline-flex', alignItems: 'center', gap: 6,
              padding: '5px 10px', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-sans)',
              background: active ? def.color : 'var(--clr-surface)',
              color:      active ? '#fff'    : 'var(--clr-text)',
              border: active ? 'none' : '1px solid var(--clr-border)',
            }}>
              <span style={{ display: 'inline-block', width: 8, height: 8, borderRadius: '50%', background: active ? 'rgba(255,255,255,0.85)' : def.color }} />
              <span>{def.label}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, opacity: 0.7 }}>{listCounts[def.id] || 0}</span>
            </button>
          );
        })}
        {selectedLists.size > 1 && (
          <span style={{ fontSize: 10, color: 'var(--clr-muted)', marginLeft: 4 }}>
            union — tickers in any selected list
          </span>
        )}
      </div>

      {/* Pillar legend */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap', alignItems: 'center' }}>
        {PILLARS.map(p => (
          <div key={p.key} style={{ display: 'flex', alignItems: 'center', gap: 5, background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 6, padding: '4px 10px' }}>
            <span style={{ fontSize: 12 }}>{p.icon}</span>
            <span style={{ fontSize: 11, fontWeight: 600, color: 'var(--clr-text)' }}>{p.label}</span>
          </div>
        ))}
        <div style={{ fontSize: 11, color: 'var(--clr-muted)', display: 'flex', gap: 10, marginLeft: 4 }}>
          <span><span style={{ color: 'var(--clr-accent)' }}>■</span> ≥70 strong</span>
          <span><span style={{ color: 'var(--clr-gold)' }}>■</span> 45–69 ok</span>
          <span><span style={{ color: 'var(--clr-red)' }}>■</span> &lt;45 weak</span>
        </div>
      </div>

      {/* Search + sector filters */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap', alignItems: 'center' }}>
        <input value={search} onChange={e => setSearch(e.target.value)}
          placeholder="Search…"
          style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 6, padding: '6px 12px', fontSize: 12, color: 'var(--clr-text)', outline: 'none', width: 150, fontFamily: 'var(--font-sans)' }} />
        {SECTORS.map(s => (
          <button key={s} onClick={() => setSector(s)} style={{
            padding: '5px 10px', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-sans)',
            background: sector === s ? 'var(--clr-accent)' : 'var(--clr-surface)',
            color: sector === s ? '#fff' : 'var(--clr-muted)',
            border: sector === s ? 'none' : '1px solid var(--clr-border)',
          }}>{s}</button>
        ))}
      </div>

      <Card>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--clr-table-head)' }}>
              <Th>Ticker</Th>
              <Th>Sector</Th>
              <Th center onClick={() => handleSort('price')}  sorted={sortKey==='price'}  dir={sortDir}>Price</Th>
              <Th center onClick={() => handleSort('mcap')}   sorted={sortKey==='mcap'}   dir={sortDir}>Mkt Cap</Th>
              {PILLARS.map(p => (
                <Th key={p.key} center onClick={() => handleSort(p.key)} sorted={sortKey===p.key} dir={sortDir}>
                  {p.icon} {p.label}
                </Th>
              ))}
              <Th center onClick={() => handleSort('overall')} sorted={sortKey==='overall'} dir={sortDir}>Overall</Th>
              <Th center>★</Th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(t => {
              const trendArrow = v => {
                const tr = trend(v);
                return <span style={{ fontSize: 9, marginLeft: 3, color: tr === 'up' ? 'var(--clr-accent)' : tr === 'down' ? 'var(--clr-red)' : 'var(--clr-muted)' }}>{tr === 'up' ? '↑' : tr === 'down' ? '↓' : '→'}</span>;
              };
              return (
                <tr
                  key={t.symbol}
                  onClick={() => onViewFundamentals(t)}
                  style={{ borderTop: '1px solid var(--clr-border)', cursor: 'pointer', transition: 'background 0.1s' }}
                  onMouseEnter={e => e.currentTarget.style.background = 'rgba(42,107,78,0.03)'}
                  onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                >
                  <td style={{ padding: '10px 14px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--clr-accent)', fontSize: 13 }}>{t.symbol}</div>
                      <ListDots lists={tickerLists(t)} />
                    </div>
                    <div style={{ fontSize: 10, color: 'var(--clr-muted)', maxWidth: 160, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.name}</div>
                  </td>
                  <td style={{ padding: '10px 14px', fontSize: 11, color: 'var(--clr-muted)', whiteSpace: 'nowrap' }}>{t.sector}</td>
                  <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center' }}>${t.price.toFixed(2)}</td>
                  <td style={{ padding: '10px 14px', fontFamily: 'var(--font-mono)', fontSize: 11, textAlign: 'center', color: 'var(--clr-muted)' }}>${t.mcap}B</td>
                  {PILLARS.map(p => {
                    const v = t[p.key];
                    const bg = v >= 70 ? 'rgba(42,107,78,0.1)' : v >= 45 ? 'rgba(154,122,58,0.1)' : 'rgba(184,60,60,0.08)';
                    const fg = pillarColor(v);
                    return (
                      <td key={p.key} style={{ padding: '10px 10px', textAlign: 'center' }}>
                        <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', minWidth: 36, height: 22, borderRadius: 5, background: bg, color: fg, fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700, gap: 2 }}>
                          {v}{trendArrow(v)}
                        </span>
                      </td>
                    );
                  })}
                  <td style={{ padding: '10px 14px', textAlign: 'center' }}>
                    <span style={{
                      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                      width: 38, height: 22, borderRadius: 5, fontFamily: 'var(--font-mono)', fontSize: 12, fontWeight: 700,
                      background: t.overall >= 70 ? 'rgba(42,107,78,0.14)' : t.overall >= 45 ? 'rgba(154,122,58,0.12)' : 'rgba(184,60,60,0.08)',
                      color: pillarColor(t.overall),
                    }}>{t.overall}</span>
                  </td>
                  <td style={{ padding: '10px 14px', textAlign: 'center' }}>
                    <button onClick={e => { e.stopPropagation(); toggleShortlist(t.symbol); }} style={{
                      width: 28, height: 28, borderRadius: 6, border: 'none', cursor: 'pointer',
                      background: t.inShortlist ? 'rgba(42,107,78,0.12)' : 'var(--clr-border)',
                      color: t.inShortlist ? 'var(--clr-accent)' : 'var(--clr-muted)',
                      fontSize: 14, display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontFamily: 'var(--font-sans)',
                    }}>{t.inShortlist ? '★' : '☆'}</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
      <p style={{ fontSize: 11, color: 'var(--clr-muted)', marginTop: 8 }}>{filtered.length} tickers shown. Click any row to open detailed fundamentals analysis.</p>
    </div>
  );
}

// ── Daily Scan ─────────────────────────────────────────────────────────────
function DailyScan({ tickers, thresholds, setThreshold, apiLive, env }) {
  const isProd = env === 'production';
  const shortlist = tickers.filter(t => t.inShortlist);

  // Live quote data keyed by symbol
  const [quotes, setQuotes]       = useState({});   // { [symbol]: Quote }
  const [quotesLoading, setQuotesLoading] = useState(false);
  const [quotesError, setQuotesError]     = useState(null);
  const [sector, setSector]         = useState('All');
  const [filterMode, setFilterMode] = useState('all');
  const { minPrice, maxPrice, maxRsi, maxBb, minPremium, minDte } = thresholds;

  // Fetch live quotes in production whenever shortlist or apiLive changes
  useEffect(() => {
    if (!isProd || !apiLive || shortlist.length === 0) return;
    setQuotesLoading(true);
    setQuotesError(null);
    const symbols = shortlist.map(t => t.symbol);
    API.getQuotes(symbols).then(d => {
      setQuotesLoading(false);
      if (!d) { setQuotesError('Could not fetch quotes.'); return; }
      const map = {};
      d.quotes.forEach(q => { map[q.symbol] = q; });
      setQuotes(map);
    });
  }, [isProd, apiLive, shortlist.length]);

  // Merge live quotes into ticker data for scan
  const enriched = useMemo(() => shortlist.map(t => {
    const q = quotes[t.symbol];
    return {
      ...t,
      price:          q?.price           ?? t.price,
      rsi:            q?.rsi             ?? t.rsi,
      bbPct:          q?.bb_pct          ?? t.bbPct,
      premiumPct:     q?.put_premium_pct ?? t.premiumPct,
      daysToEarnings: q?.days_to_earnings ?? t.daysToEarnings,
      hasLiveQuote:   !!q,
    };
  }), [shortlist, quotes]);

  const withResults = useMemo(() => enriched.map(t => {
    const checks = {
      price:   { pass: t.price >= minPrice && t.price <= maxPrice,  label: 'Price',    value: `$${t.price.toFixed(2)}`,      threshold: `$${minPrice}–$${maxPrice}` },
      rsi:     { pass: t.rsi <= maxRsi,                              label: 'RSI',      value: `${t.rsi}`,                    threshold: `≤ ${maxRsi}` },
      bb:      { pass: t.bbPct <= maxBb,                             label: 'BB%',      value: `${t.bbPct}%`,                 threshold: `≤ ${maxBb}%` },
      premium: { pass: t.premiumPct >= minPremium,                   label: 'Premium',  value: `${t.premiumPct.toFixed(2)}%`, threshold: `≥ ${minPremium}%` },
      dte:     { pass: t.daysToEarnings >= minDte,                   label: 'Earnings', value: `${t.daysToEarnings}d`,        threshold: `≥ ${minDte}d` },
    };
    const passCount = Object.values(checks).filter(c => c.pass).length;
    return { ...t, checks, passCount, allPass: passCount === 5 };
  }), [enriched, thresholds]);

  const filtered = useMemo(() => {
    let list = withResults;
    if (sector !== 'All') list = list.filter(t => t.sector === sector);
    if (filterMode === 'passing') list = list.filter(t => t.allPass);
    if (filterMode === 'partial') list = list.filter(t => t.passCount >= 3 && !t.allPass);
    return [...list].sort((a, b) => b.passCount - a.passCount);
  }, [withResults, sector, filterMode]);

  const passing = withResults.filter(t => t.allPass);
  const partial  = withResults.filter(t => t.passCount >= 3 && !t.allPass);

  // Production with no connection
  if (isProd && !apiLive) {
    return (
      <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
        <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 700, margin: '0 0 12px', fontStyle: 'italic' }}>Daily Scan</h2>
        <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 10, padding: '32px', textAlign: 'center', color: 'var(--clr-muted)' }}>
          <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 8 }}>Live quotes unavailable</div>
          <div style={{ fontSize: 13 }}>Connect IBKR to fetch real-time price, RSI, BB%, and premium data.</div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 18 }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 700, margin: 0, fontStyle: 'italic' }}>Daily Scan</h2>
          <p style={{ margin: '4px 0 0', color: 'var(--clr-muted)', fontSize: 13 }}>
            {quotesLoading
              ? 'Fetching live quotes…'
              : quotesError
              ? quotesError
              : passing.length > 0
              ? `${passing.length} setup${passing.length > 1 ? 's' : ''} fully aligned — take your time, no rush.`
              : `No full alignments today. ${partial.length} partial${partial.length !== 1 ? 's' : ''} worth watching.`}
            {isProd && !quotesLoading && Object.keys(quotes).length > 0 &&
              <span style={{ marginLeft: 8, color: 'var(--clr-accent)', fontSize: 11 }}>· live quotes</span>}
            {!isProd &&
              <span style={{ marginLeft: 8, color: 'var(--clr-gold)', fontSize: 11 }}>· mock data</span>}
          </p>
        </div>
        <button style={{ fontSize: 12, color: 'var(--clr-muted)', background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 6, padding: '6px 14px', cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>
          ↑ Export to Sheets
        </button>
      </div>

      {/* Summary cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'auto auto auto 1fr', gap: 10, marginBottom: 20 }}>
        {[
          { count: passing.length, label: 'All criteria pass', sub: 'Ready to evaluate', color: 'var(--clr-accent)', bg: 'rgba(42,107,78,0.08)', border: 'rgba(42,107,78,0.18)' },
          { count: partial.length, label: '3–4 criteria pass', sub: 'Worth watching', color: 'var(--clr-gold)', bg: 'rgba(154,122,58,0.08)', border: 'rgba(154,122,58,0.18)' },
          { count: withResults.length - passing.length - partial.length, label: 'Not aligned', sub: 'Skip for now', color: 'var(--clr-muted)', bg: 'transparent', border: 'var(--clr-border)' },
        ].map((s, i) => (
          <div key={i} style={{ background: s.bg, border: `1px solid ${s.border}`, borderRadius: 8, padding: '12px 18px', display: 'flex', gap: 12, alignItems: 'center' }}>
            <span style={{ fontSize: 26, fontWeight: 700, fontFamily: 'var(--font-mono)', color: s.color, lineHeight: 1 }}>{s.count}</span>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: s.color }}>{s.label}</div>
              <div style={{ fontSize: 11, color: 'var(--clr-muted)' }}>{s.sub}</div>
            </div>
          </div>
        ))}
        <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 8, padding: '12px 18px' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.06em', fontWeight: 600 }}>Active thresholds</div>
            <span style={{ fontSize: 9, color: 'var(--clr-muted)', fontStyle: 'italic' }}>click to edit</span>
          </div>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center', rowGap: 6 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 2 }}>
              <span style={{ fontSize: 10, color: 'var(--clr-muted)', marginRight: 2 }}>Price</span>
              <ThresholdNumInput value={minPrice} onChange={v => setThreshold && setThreshold('minPrice', v)} min={1} max={Math.max(2, maxPrice - 1)} step={1} prefix="$" width={48} />
              <span style={{ fontSize: 11, color: 'var(--clr-muted)' }}>–</span>
              <ThresholdNumInput value={maxPrice} onChange={v => setThreshold && setThreshold('maxPrice', v)} min={Math.min(minPrice + 1, 199)} max={200} step={5} prefix="$" width={52} />
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <span style={{ fontSize: 10, color: 'var(--clr-muted)' }}>RSI ≤</span>
              <ThresholdNumInput value={maxRsi} onChange={v => setThreshold && setThreshold('maxRsi', v)} min={20} max={80} step={1} width={42} />
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <span style={{ fontSize: 10, color: 'var(--clr-muted)' }}>BB ≤</span>
              <ThresholdNumInput value={maxBb} onChange={v => setThreshold && setThreshold('maxBb', v)} min={5} max={100} step={1} suffix="%" width={48} />
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <span style={{ fontSize: 10, color: 'var(--clr-muted)' }}>Prem ≥</span>
              <ThresholdNumInput value={minPremium} onChange={v => setThreshold && setThreshold('minPremium', v)} min={0.1} max={5} step={0.1} suffix="%" width={52} decimals={1} />
            </span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
              <span style={{ fontSize: 10, color: 'var(--clr-muted)' }}>Earnings ≥</span>
              <ThresholdNumInput value={minDte} onChange={v => setThreshold && setThreshold('minDte', v)} min={0} max={60} step={1} suffix="d" width={48} />
            </span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 14, flexWrap: 'wrap', alignItems: 'center' }}>
        {[['all','All'],['passing','Passing only'],['partial','Partial (3–4)']].map(([v,l]) => (
          <button key={v} onClick={() => setFilterMode(v)} style={{
            padding: '5px 12px', borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-sans)',
            background: filterMode === v ? 'var(--clr-accent)' : 'var(--clr-surface)',
            color: filterMode === v ? '#fff' : 'var(--clr-muted)',
            border: filterMode === v ? 'none' : '1px solid var(--clr-border)',
          }}>{l}</button>
        ))}
        <div style={{ width: 1, height: 18, background: 'var(--clr-border)' }} />
        {['All', ...new Set(shortlist.map(t => t.sector))].map(s => (
          <button key={s} onClick={() => setSector(s)} style={{
            padding: '5px 10px', borderRadius: 6, fontSize: 11, cursor: 'pointer', fontFamily: 'var(--font-sans)',
            background: sector === s ? 'rgba(154,122,58,0.12)' : 'transparent',
            color: sector === s ? 'var(--clr-gold)' : 'var(--clr-muted)',
            border: sector === s ? '1px solid rgba(154,122,58,0.25)' : '1px solid transparent',
          }}>{s}</button>
        ))}
      </div>

      <Card>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: 'var(--clr-table-head)' }}>
              <Th>Ticker</Th>
              {['Price','RSI','BB%','Premium','Earnings'].map(l => <Th key={l} center>{l}</Th>)}
              <Th center>Score</Th>
              <Th center>Status</Th>
            </tr>
          </thead>
          <tbody>
            {filtered.map(t => (
              <tr key={t.symbol} style={{ borderTop: '1px solid var(--clr-border)' }}>
                <td style={{ padding: '10px 14px' }}>
                  <div style={{ fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--clr-accent)', fontSize: 13 }}>{t.symbol}</div>
                  <div style={{ fontSize: 10, color: 'var(--clr-muted)' }}>
                    {t.sector}
                    {t.hasLiveQuote && <span style={{ marginLeft: 6, color: 'var(--clr-accent)' }}>●</span>}
                  </div>
                </td>
                {['price','rsi','bb','premium','dte'].map(c => {
                  const check = t.checks[c];
                  return (
                    <td key={c} style={{ padding: '10px 14px', textAlign: 'center' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 1 }}>
                        <span style={{ fontSize: 14, lineHeight: 1, color: check.pass ? 'var(--clr-accent)' : 'var(--clr-red)' }}>{check.pass ? '✓' : '✗'}</span>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: check.pass ? 'var(--clr-text)' : 'var(--clr-muted)' }}>{check.value}</span>
                        <span style={{ fontSize: 9, color: 'var(--clr-muted)' }}>{check.threshold}</span>
                      </div>
                    </td>
                  );
                })}
                <td style={{ padding: '10px 14px', textAlign: 'center' }}>
                  <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 15, color: t.passCount === 5 ? 'var(--clr-accent)' : t.passCount >= 3 ? 'var(--clr-gold)' : 'var(--clr-muted)' }}>
                    {t.passCount}/5
                  </span>
                </td>
                <td style={{ padding: '10px 14px', textAlign: 'center' }}>
                  {t.allPass
                    ? <span style={{ background: 'rgba(42,107,78,0.1)', color: 'var(--clr-accent)', border: '1px solid rgba(42,107,78,0.2)', fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 999 }}>Aligned ✓</span>
                    : t.passCount >= 3
                    ? <span style={{ background: 'rgba(154,122,58,0.1)', color: 'var(--clr-gold)', border: '1px solid rgba(154,122,58,0.2)', fontSize: 11, fontWeight: 600, padding: '3px 10px', borderRadius: 999 }}>Partial</span>
                    : <span style={{ fontSize: 11, color: 'var(--clr-muted)', padding: '3px 10px' }}>—</span>
                  }
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
      <p style={{ fontSize: 11, color: 'var(--clr-muted)', marginTop: 8 }}>{filtered.length} tickers shown. Adjust thresholds in Tweaks.</p>
    </div>
  );
}

Object.assign(window, { Shortlist, DailyScan });
