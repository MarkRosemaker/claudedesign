// components.jsx — shared primitives, Dashboard, Portfolio
const { useState, useEffect, useMemo } = React;

// ── SVG micro-chart ─────────────────────────────────────────────────────────
function LineChart({ points, color = 'var(--clr-accent)', width = 120, height = 44, fill = false }) {
  if (!points || points.length < 2) return <div style={{ width, height, background: 'var(--clr-border)', borderRadius: 4 }} />;
  const vals = points.map(p => p.value ?? p.y ?? 0);
  const minV = Math.min(...vals), maxV = Math.max(...vals);
  const rangeV = maxV - minV || 1;
  const px = (i) => (i / (points.length - 1)) * width;
  const py = (v) => height - 4 - ((v - minV) / rangeV) * (height - 8);
  const d = vals.map((v, i) => `${i === 0 ? 'M' : 'L'}${px(i).toFixed(1)},${py(v).toFixed(1)}`).join(' ');
  const fillD = fill ? `${d} L${width},${height} L0,${height} Z` : null;
  return (
    <svg width={width} height={height} style={{ display: 'block', overflow: 'visible' }}>
      {fill && <path d={fillD} fill={color} fillOpacity={0.08} />}
      <path d={d} fill="none" stroke={color} strokeWidth="1.75" strokeLinejoin="round" strokeLinecap="round" />
      {/* last dot */}
      <circle cx={px(vals.length - 1).toFixed(1)} cy={py(vals[vals.length - 1]).toFixed(1)} r="2.5" fill={color} />
    </svg>
  );
}

function BarChart({ points, color = 'var(--clr-accent)', width = 120, height = 44 }) {
  if (!points || points.length === 0) return null;
  const vals = points.map(p => p.value ?? p.y ?? 0);
  const maxV = Math.max(...vals.map(Math.abs), 0.01);
  const barW = Math.max(4, (width / vals.length) - 2);
  return (
    <svg width={width} height={height} style={{ display: 'block' }}>
      {vals.map((v, i) => {
        const barH = Math.max(2, (Math.abs(v) / maxV) * (height - 4));
        const x = (i / vals.length) * width + 1;
        const y = v >= 0 ? height - 2 - barH : height - 2 - barH;
        const c = v >= 0 ? color : 'var(--clr-red)';
        return <rect key={i} x={x} y={y} width={barW} height={barH} fill={c} fillOpacity={0.7} rx="1" />;
      })}
    </svg>
  );
}

// ── Shared UI atoms ──────────────────────────────────────────────────────────
function Card({ children, style }) {
  return <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 10, overflow: 'hidden', ...style }}>{children}</div>;
}

function CardHeader({ children, border = true }) {
  return <div style={{ padding: '13px 18px', borderBottom: border ? '1px solid var(--clr-border)' : 'none', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>{children}</div>;
}

function Th({ children, center, right, onClick, sorted, dir }) {
  return (
    <th onClick={onClick} style={{
      padding: '8px 14px', textAlign: center ? 'center' : right ? 'right' : 'left',
      fontSize: 10, color: sorted ? 'var(--clr-accent)' : 'var(--clr-muted)',
      fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase',
      whiteSpace: 'nowrap', cursor: onClick ? 'pointer' : 'default', userSelect: 'none',
    }}>
      {children}{sorted ? (dir === 'desc' ? ' ↓' : ' ↑') : ''}
    </th>
  );
}

function ScorePill({ value }) {
  const bg = value >= 70 ? 'rgba(42,107,78,0.12)' : value >= 45 ? 'rgba(154,122,58,0.1)' : 'rgba(184,60,60,0.08)';
  const fg = value >= 70 ? 'var(--clr-accent)' : value >= 45 ? 'var(--clr-gold)' : 'var(--clr-red)';
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', minWidth: 32, height: 20, borderRadius: 4, background: bg, color: fg, fontFamily: 'var(--font-mono)', fontSize: 11, fontWeight: 700 }}>
      {value}
    </span>
  );
}

function TrendArrow({ trend }) {
  if (!trend) return null;
  return <span style={{ fontSize: 10, marginLeft: 3, color: trend === 'up' ? 'var(--clr-accent)' : trend === 'down' ? 'var(--clr-red)' : 'var(--clr-muted)' }}>{trend === 'up' ? '↑' : trend === 'down' ? '↓' : '→'}</span>;
}

function StatCard({ label, value, sub, accent, small }) {
  return (
    <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 10, padding: small ? '14px 18px' : '18px 22px', display: 'flex', flexDirection: 'column', gap: 4 }}>
      <div style={{ fontSize: 10, color: 'var(--clr-muted)', letterSpacing: '0.07em', textTransform: 'uppercase', fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: small ? 22 : 26, fontWeight: 700, color: accent || 'var(--clr-text)', fontFamily: 'var(--font-mono)', lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--clr-muted)', marginTop: 1 }}>{sub}</div>}
    </div>
  );
}

function LiveBadge({ live }) {
  const isDev = window.ENV === 'development';
  const label = isDev ? 'Dev · mock data' : live ? 'Live' : 'Offline · mock data';
  const color = isDev ? 'var(--clr-gold)' : live ? 'var(--clr-accent)' : 'var(--clr-muted)';
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11, fontWeight: 600, color }}>
      <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: color, boxShadow: live && !isDev ? '0 0 0 2px rgba(42,107,78,0.2)' : 'none' }} />
      {label}
    </span>
  );
}

function PassFail({ pass, label }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4, padding: '2px 8px', borderRadius: 999,
      fontSize: 11, fontWeight: 600,
      background: pass ? 'rgba(42,107,78,0.1)' : 'rgba(184,60,60,0.08)',
      color: pass ? 'var(--clr-accent)' : 'var(--clr-red)',
      border: `1px solid ${pass ? 'rgba(42,107,78,0.2)' : 'rgba(184,60,60,0.18)'}`,
    }}>
      <span style={{ fontSize: 8 }}>●</span>{label}
    </span>
  );
}

// ── Dashboard ───────────────────────────────────────────────────────────────
function Dashboard({ tickers, mockPositions, thresholds, onNav, apiLive, accounts, env, brokerStatus }) {
  const [marketStatus, setMarketStatus] = useState(null);
  const [accountSummary, setAccountSummary] = useState(null);
  const isProd = env === 'production';

  useEffect(() => {
    API.getMarketStatus().then(d => d && setMarketStatus(d));
  }, []);

  useEffect(() => {
    if (!accounts?.length) return;
    API.getAccountSummary(accounts[0].account_id).then(d => d && setAccountSummary(d));
  }, [accounts]);

  const shortlist = tickers.filter(t => t.inShortlist);
  const { minPrice, maxPrice, maxRsi, maxBb, minPremium, minDte } = thresholds;
  const passing = shortlist.filter(t =>
    t.price >= minPrice && t.price <= maxPrice && t.rsi <= maxRsi &&
    t.bbPct <= maxBb && t.premiumPct >= minPremium && t.daysToEarnings >= minDte
  );

  const liveOptions  = accountSummary?.options   || [];
  const liveBalances = accountSummary?.balances   || [];
  const usd = liveBalances.find(b => b.currency === 'USD');

  // Open positions: live if available, mock only in development
  const openPos   = isProd ? [] : mockPositions.filter(p => p.status === 'open');
  const closedPos = isProd ? [] : mockPositions.filter(p => p.status === 'closed');

  // Use live options when available, mock only in dev
  const displayOptions = liveOptions.length ? liveOptions : (isProd ? [] : openPos);
  const expiringSoon = displayOptions.filter(p => (p.days_to_expiry ?? p.dte ?? 99) <= 7);

  // Account value = sum of option market values + cash
  // In live mode we get it from accountSummary; in dev we estimate
  const liveCash = usd?.cash ?? null;
  const liveOptionValue = liveOptions.reduce((s, o) => s + (o.market_value ?? 0), 0);
  const mockPnL = openPos.reduce((s, p) => s + (p.pnl || 0), 0);

  const today = marketStatus?.today || new Date().toISOString().slice(0, 10);
  const isTradingDay = marketStatus?.is_trading_day ?? true;
  const nextFriday = marketStatus?.next_friday;
  const greet = new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening';

  const sectors = ['Technology','Finance','Healthcare','Energy','Consumer','Industrial','Telecom','Media'];

  // Production with no data yet
  if (isProd && !apiLive) {
    return (
      <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
          <div>
            <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 28, fontWeight: 700, color: 'var(--clr-text)', margin: 0, fontStyle: 'italic' }}>{greet}.</h1>
            <p style={{ margin: '5px 0 0', color: 'var(--clr-muted)', fontSize: 13 }}>Waiting for IBKR gateway…</p>
          </div>
          <LiveBadge live={false} />
        </div>
        <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 10, padding: '32px', textAlign: 'center', color: 'var(--clr-muted)' }}>
          <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 8 }}>Not connected to IBKR</div>
          <div style={{ fontSize: 13 }}>{brokerStatus?.connected === false ? 'Start the IBKR gateway and re-authenticate.' : 'Backend unreachable — is the server running?'}</div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
      {/* Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 28, fontWeight: 700, color: 'var(--clr-text)', margin: 0, letterSpacing: '-0.02em', fontStyle: 'italic' }}>{greet}.</h1>
          <p style={{ margin: '5px 0 0', color: 'var(--clr-muted)', fontSize: 13, lineHeight: 1.5 }}>
            {!isTradingDay ? 'Markets are closed today — a good day to review your shortlist.'
              : passing.length === 0 ? 'No setups aligned today — no rush, check back tomorrow.'
              : `${passing.length} setup${passing.length > 1 ? 's' : ''} aligned today — take your time.`}
          </p>
        </div>
        <div style={{ textAlign: 'right', display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'flex-end' }}>
          <LiveBadge live={apiLive} />
          <div style={{ fontSize: 11, color: 'var(--clr-muted)', fontFamily: 'var(--font-mono)' }}>
            {today}{nextFriday ? ` · next expiry ${nextFriday}` : ''}
          </div>
        </div>
      </div>

      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 24 }}>
        {/* Available cash for options trading */}
        <StatCard
          label="Available"
          value={liveCash != null ? `$${liveCash.toLocaleString(undefined, {maximumFractionDigits: 0})}` : (isProd ? '—' : '$12,400')}
          sub={liveCash != null ? 'Cash for options' : (isProd ? 'Connect IBKR' : 'Mock — connect IBKR')}
          accent={liveCash != null ? 'var(--clr-accent)' : 'var(--clr-muted)'}
        />
        {/* Total portfolio value */}
        <StatCard
          label="Value"
          value={accountSummary ? `$${(liveCash + liveOptionValue).toLocaleString(undefined, {maximumFractionDigits: 0})}` : (isProd ? '—' : '$14,820')}
          sub={accountSummary ? 'Cash + option positions' : (isProd ? 'Connect IBKR' : 'Mock — connect IBKR')}
          accent={accountSummary ? 'var(--clr-accent)' : 'var(--clr-muted)'}
        />
        {/* Open positions count */}
        <StatCard
          label="Open Positions"
          value={liveOptions.length || (isProd ? '—' : openPos.length)}
          sub={expiringSoon.length > 0 ? `${expiringSoon.length} expiring within 7d` : (liveOptions.length || !isProd ? 'All within range' : 'Connect IBKR')}
          accent={expiringSoon.length > 0 ? 'var(--clr-gold)' : undefined}
        />
        {/* Setups today */}
        <StatCard
          label="Setups Today"
          value={shortlist.length > 0 ? passing.length : '—'}
          accent={passing.length > 0 ? 'var(--clr-accent)' : 'var(--clr-muted)'}
          sub={shortlist.length > 0 ? `of ${shortlist.length} shortlisted` : 'Add tickers to shortlist'}
        />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 16 }}>
        {/* Aligned setups */}
        <Card>
          <CardHeader>
            <span style={{ fontSize: 13, fontWeight: 600 }}>Aligned Setups</span>
            <button onClick={() => onNav('scan')} style={{ fontSize: 11, color: 'var(--clr-accent)', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>Full scan →</button>
          </CardHeader>
          {passing.length === 0
            ? <div style={{ padding: '28px 18px', textAlign: 'center', color: 'var(--clr-muted)', fontSize: 13 }}>
                {shortlist.length === 0 ? 'Add tickers to your shortlist to see setups.' : 'No setups passing all criteria today.'}
              </div>
            : <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr style={{ background: 'var(--clr-table-head)' }}>
                  <Th>Ticker</Th><Th center>Price</Th><Th center>RSI</Th><Th center>BB%</Th><Th center>Premium</Th>
                </tr></thead>
                <tbody>{passing.slice(0,6).map(t => (
                  <tr key={t.symbol} style={{ borderTop: '1px solid var(--clr-border)' }}>
                    <td style={{ padding: '9px 14px', fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--clr-accent)', fontSize: 13 }}>{t.symbol}</td>
                    <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center' }}>${t.price.toFixed(2)}</td>
                    <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center', color: 'var(--clr-accent)' }}>{t.rsi}</td>
                    <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center', color: 'var(--clr-accent)' }}>{t.bbPct}%</td>
                    <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center', color: 'var(--clr-accent)' }}>{t.premiumPct.toFixed(2)}%</td>
                  </tr>
                ))}</tbody>
              </table>
          }
        </Card>

        {/* Open positions */}
        <Card>
          <CardHeader>
            <span style={{ fontSize: 13, fontWeight: 600 }}>{liveOptions.length ? 'Positions (Live)' : 'Open Positions'}</span>
            <button onClick={() => onNav('portfolio')} style={{ fontSize: 11, color: 'var(--clr-accent)', background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>Portfolio →</button>
          </CardHeader>
          {displayOptions.length === 0
            ? <div style={{ padding: '28px 18px', textAlign: 'center', color: 'var(--clr-muted)', fontSize: 13 }}>
                {isProd ? 'No open positions.' : 'No positions to display.'}
              </div>
            : <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead><tr style={{ background: 'var(--clr-table-head)' }}>
                  <Th>Position</Th><Th center>Strike</Th><Th center>DTE</Th><Th center>P&L</Th><Th center>Capture</Th>
                </tr></thead>
                <tbody>{displayOptions.slice(0,8).map((p,i) => (
                  <tr key={i} style={{ borderTop: '1px solid var(--clr-border)' }}>
                    <td style={{ padding: '9px 14px', fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--clr-accent)', fontSize: 13 }}>{p.underlying || p.symbol} {p.type}</td>
                    <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center' }}>${p.strike}</td>
                    <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center', color: (p.days_to_expiry ?? p.dte ?? 99) <= 7 ? 'var(--clr-gold)' : 'inherit' }}>{p.days_to_expiry ?? p.dte ?? '—'}d</td>
                    <td style={{ padding: '9px 14px', fontFamily: 'var(--font-mono)', fontSize: 12, textAlign: 'center', fontWeight: 600, color: (p.pnl||0) >= 0 ? 'var(--clr-accent)' : 'var(--clr-red)' }}>{(p.pnl||0) >= 0 ? '+' : ''}${(p.pnl||0).toFixed(0)}</td>
                    <td style={{ padding: '9px 14px', textAlign: 'center' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 5, justifyContent: 'center' }}>
                        <div style={{ width: 36, height: 3, background: 'var(--clr-border)', borderRadius: 2 }}>
                          <div style={{ width: `${Math.min(100, p.profitCapture||0)}%`, height: '100%', background: 'var(--clr-accent)', borderRadius: 2 }} />
                        </div>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--clr-muted)' }}>{(p.profitCapture||0).toFixed(0)}%</span>
                      </div>
                    </td>
                  </tr>
                ))}</tbody>
              </table>
          }
        </Card>
      </div>

      {/* Shortlist sector strip */}
      <Card>
        <div style={{ padding: '12px 20px', display: 'flex', gap: 28, alignItems: 'center', flexWrap: 'wrap' }}>
          <div>
            <div style={{ fontSize: 10, color: 'var(--clr-muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 2 }}>Shortlist</div>
            <div style={{ fontSize: 14, fontWeight: 600 }}>{shortlist.length} tickers</div>
          </div>
          {sectors.map(sector => {
            const count = shortlist.filter(t => t.sector === sector).length;
            return count > 0 ? (
              <div key={sector} style={{ textAlign: 'center' }}>
                <div style={{ fontSize: 10, color: 'var(--clr-muted)', marginBottom: 1 }}>{sector}</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontSize: 16, fontWeight: 700 }}>{count}</div>
              </div>
            ) : null;
          })}
          <button onClick={() => onNav('shortlist')} style={{ marginLeft: 'auto', fontSize: 12, color: 'var(--clr-accent)', background: 'rgba(42,107,78,0.08)', border: '1px solid rgba(42,107,78,0.2)', borderRadius: 6, padding: '6px 14px', cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>
            Manage shortlist →
          </button>
        </div>
      </Card>
    </div>
  );
}

// ── Portfolio ────────────────────────────────────────────────────────────────
function Portfolio({ mockPositions, tickers, apiLive, accounts, env }) {
  const [liveData, setLiveData] = useState(null);
  const [cashData, setCashData] = useState(null);
  const [filter, setFilter] = useState('open');
  const isProd = env === 'production';

  useEffect(() => {
    if (!accounts?.length) return;
    const id = accounts[0].account_id;
    Promise.all([API.getPositions(id), API.getCash(id)]).then(([pos, cash]) => {
      if (pos) setLiveData(pos);
      if (cash) setCashData(cash);
    });
  }, [accounts]);

  // In production, only show live data. In development, fall back to mock.
  const open   = isProd ? [] : mockPositions.filter(p => p.status === 'open');
  const closed = isProd ? [] : mockPositions.filter(p => p.status === 'closed');

  const liveOptions = liveData?.options || [];
  const liveStocks  = liveData?.stocks  || [];
  const usd = cashData?.balances?.find(b => b.currency === 'USD');
  const asOf = liveData?.as_of ? new Date(liveData.as_of).toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'}) : null;

  // Use live options when available, mock only in dev
  const displayOpen   = liveOptions.length ? liveOptions : open;
  const displayClosed = closed; // closed history not in live API yet

  const mockPnL      = open.reduce((s,p) => s+(p.pnl||0), 0);
  const mockRealized = closed.reduce((s,p) => s+(p.pnl||0), 0);
  const avgCapture   = displayOpen.length
    ? (displayOpen.reduce((s,p) => s+(p.profitCapture||0), 0) / displayOpen.length).toFixed(0)
    : '—';

  // Production with no connection
  if (isProd && !apiLive) {
    return (
      <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
        <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 700, margin: '0 0 12px', fontStyle: 'italic' }}>Portfolio</h2>
        <div style={{ background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 10, padding: '32px', textAlign: 'center', color: 'var(--clr-muted)' }}>
          <div style={{ fontSize: 15, fontWeight: 600, marginBottom: 8 }}>Not connected to IBKR</div>
          <div style={{ fontSize: 13 }}>Start the IBKR gateway to see live positions and cash.</div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: '28px 32px', maxWidth: 1100, margin: '0 auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 20 }}>
        <div>
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: 22, fontWeight: 700, margin: 0, fontStyle: 'italic' }}>Portfolio</h2>
          <p style={{ margin: '4px 0 0', color: 'var(--clr-muted)', fontSize: 13 }}>
            {apiLive && asOf ? `Live from IBKR · updated ${asOf}` : isProd ? 'Connecting…' : 'Mock data — connect IBKR for live positions'}
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <LiveBadge live={apiLive} />
          <button style={{ fontSize: 12, color: 'var(--clr-muted)', background: 'var(--clr-surface)', border: '1px solid var(--clr-border)', borderRadius: 6, padding: '6px 14px', cursor: 'pointer', fontFamily: 'var(--font-sans)' }}>↑ Export to Sheets</button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 20 }}>
        <StatCard small label="Available Cash"
          value={usd ? `$${usd.cash.toLocaleString(undefined,{maximumFractionDigits:0})}` : (isProd ? '—' : '$12,400')}
          accent={usd ? 'var(--clr-accent)' : 'var(--clr-muted)'}
        />
        <StatCard small label="Portfolio Value"
          value={usd && liveOptions.length
            ? `$${(usd.cash + liveOptions.reduce((s,o) => s+(o.market_value??0),0)).toLocaleString(undefined,{maximumFractionDigits:0})}`
            : (isProd ? '—' : '$14,820')}
          accent={usd ? 'var(--clr-accent)' : 'var(--clr-muted)'}
        />
        <StatCard small label="Option Positions"
          value={liveOptions.length || (isProd ? '—' : open.length)}
          sub={liveStocks.length ? `+ ${liveStocks.length} stock positions` : (isProd ? '' : `${closed.length} closed`)}
        />
        <StatCard small label="Avg Profit Capture"
          value={avgCapture === '—' ? '—' : `${avgCapture}%`}
          accent="var(--clr-accent)"
        />
      </div>

      <div style={{ display: 'flex', gap: 4, marginBottom: 14 }}>
        {[['open',`Open (${liveOptions.length || (isProd ? 0 : open.length)})`],['closed',`Closed (${isProd ? 0 : closed.length})`]].map(([v,l]) => (
          <button key={v} onClick={() => setFilter(v)} style={{
            padding: '6px 14px', borderRadius: 6, fontSize: 12, fontWeight: 600, cursor: 'pointer', fontFamily: 'var(--font-sans)',
            background: filter===v ? 'var(--clr-accent)' : 'var(--clr-surface)',
            color: filter===v ? '#fff' : 'var(--clr-muted)',
            border: filter===v ? 'none' : '1px solid var(--clr-border)',
          }}>{l}</button>
        ))}
      </div>

      <Card>
        {(filter === 'open' ? displayOpen : displayClosed).length === 0
          ? <div style={{ padding: '32px', textAlign: 'center', color: 'var(--clr-muted)', fontSize: 13 }}>
              {filter === 'open'
                ? (isProd ? 'No open positions.' : 'No open positions to show.')
                : 'No closed positions this cycle.'}
            </div>
          : <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead><tr style={{ background: 'var(--clr-table-head)' }}>
                <Th>Position</Th><Th>Expiry</Th><Th center>Strike</Th><Th center>Contracts</Th><Th center>DTE</Th><Th center>Open Prem</Th><Th center>Curr Prem</Th><Th center>P&L</Th><Th center>Capture</Th>
              </tr></thead>
              <tbody>
                {(filter === 'open' ? displayOpen : displayClosed).map((p,i) => (
                  <tr key={i} style={{ borderTop: '1px solid var(--clr-border)', opacity: p.status==='closed' ? 0.65 : 1 }}>
                    <td style={{ padding: '11px 14px' }}>
                      <div style={{ fontWeight: 700, fontFamily: 'var(--font-mono)', color: 'var(--clr-accent)', fontSize: 13 }}>{p.underlying || p.symbol} {p.type}</div>
                    </td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--clr-muted)' }}>{p.expiry}</td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--font-mono)', textAlign: 'center' }}>${p.strike}</td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--font-mono)', textAlign: 'center' }}>{p.qty ?? p.contracts}</td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--font-mono)', textAlign: 'center', color: (p.days_to_expiry??p.dte??99)<=7&&p.status!=='closed'?'var(--clr-gold)':'inherit' }}>
                      {(p.days_to_expiry??p.dte)>0 ? `${p.days_to_expiry??p.dte}d` : '—'}
                    </td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--font-mono)', textAlign: 'center', color: 'var(--clr-muted)' }}>{p.openPremium != null ? `$${p.openPremium.toFixed(2)}` : '—'}</td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--font-mono)', textAlign: 'center' }}>{p.status==='open'&&p.currentPremium!=null?`$${p.currentPremium.toFixed(2)}`:'—'}</td>
                    <td style={{ padding: '11px 14px', fontFamily: 'var(--font-mono)', textAlign: 'center', fontWeight: 600, color: (p.pnl||0)>=0?'var(--clr-accent)':'var(--clr-red)' }}>{p.pnl!=null?`${p.pnl>=0?'+':''}$${p.pnl.toFixed(0)}`:'—'}</td>
                    <td style={{ padding: '11px 14px', textAlign: 'center' }}>
                      {p.profitCapture != null ? (
                        <div style={{ display: 'flex', alignItems: 'center', gap: 5, justifyContent: 'center' }}>
                          <div style={{ width: 40, height: 3, background: 'var(--clr-border)', borderRadius: 2 }}>
                            <div style={{ width: `${Math.min(100,p.profitCapture)}%`, height: '100%', background: 'var(--clr-accent)', borderRadius: 2 }} />
                          </div>
                          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--clr-muted)' }}>{p.profitCapture.toFixed(0)}%</span>
                        </div>
                      ) : <span style={{ color: 'var(--clr-muted)', fontSize: 11 }}>—</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
        }
      </Card>
      <p style={{ fontSize: 11, color: 'var(--clr-muted)', marginTop: 10 }}>Trade placement is planned for a future release.</p>
    </div>
  );
}

Object.assign(window, { LineChart, BarChart, Card, CardHeader, Th, ScorePill, TrendArrow, StatCard, LiveBadge, PassFail, Dashboard, Portfolio });
